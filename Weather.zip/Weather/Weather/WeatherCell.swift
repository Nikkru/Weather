//
//  WeatherCell.swift
//  Weather
//
//  Created by Nikolai Krusser on 08.11.2021.
//

import UIKit

class WeatherCell: UICollectionViewCell {
    @IBOutlet weak var weather: UILabel!
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var time: UILabel!
    
}
